// Iteration 1: Names and Input


// Iteration 2: Conditionals

// Iteration 3: Loops
// Iteration 3.1 'Name' to 'N A M E'

// Iteration 3.2 'Name' to 'emaN'

// Iteration 3.3 Lexicographic order


// Bonus 1: Palindromes

// Bonus 2: Lorem ipsum counter
