console.log("Gustavo Cerati es el mejor guitarrista de Sur America");

console.log("Ikerne");
